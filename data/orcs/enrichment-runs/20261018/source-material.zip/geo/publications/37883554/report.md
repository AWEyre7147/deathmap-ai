# GEO accessions — PMID 37883554

Unbiased transcription factor CRISPR screen identifies ZNF800 as master repressor of enteroendocrine differentiation.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE229583 | False | 37883554 | matches_origin |
| GSE229584 | False | 37883554 | matches_origin |
| GSE229585 | False | 37883554 | matches_origin |
| GSE229586 | False | 37883554 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
