# GEO accessions — PMID 33417871

UM171 Preserves Epigenetic Marks that Are Reduced in Ex Vivo Culture of Human HSCs via Potentiation of the CLR3-KBTBD4 Complex.

4 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE156900 | True | 33022376 | different_publication |
| GSE157294 | False | 33417871 | matches_origin |
| GSE157295 | False | 33417871 | matches_origin |
| GSE157296 | False | 33417871, 39747844 | matches_origin |
| GSE157298 | False | 33022376, 33417871, 39747844 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 5 |
