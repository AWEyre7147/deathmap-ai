# GEO accessions — PMID unavailable

TMEM106B-mediated SARS-CoV-2 infection allows for robust ACE2-independent infection in vitro but not in vivo

0 seed accessions; 0 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | skipped_missing_pmid | 0 |
| pubmed_accession_list | skipped_missing_pmid | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | skipped_missing_pmid | 0 |
| europepmc_datalinks | skipped_missing_pmid | 0 |
| pubmed_bioproject_geo | skipped_missing_pmid | 0 |
| series_hierarchy | complete | 0 |
