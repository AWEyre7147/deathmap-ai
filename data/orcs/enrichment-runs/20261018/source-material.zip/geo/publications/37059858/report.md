# GEO accessions — PMID 37059858

A multi-omics integrative analysis based on CRISPR screens re-defines the pluripotency regulatory network in ESCs.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE120224 | False | 30951980 | different_publication |
| GSE120963 | False | 31391582 | different_publication |
| GSE143371 | False | 32735778 | different_publication |
| GSE219206 | False | 37059858 | matches_origin |
| GSE53387 | False | 30026265, 30767785 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
