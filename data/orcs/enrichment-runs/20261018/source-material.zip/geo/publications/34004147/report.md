# GEO accessions — PMID 34004147

The PP2A-Integrator-CDK9 axis fine-tunes transcription and can be targeted therapeutically in cancer.

7 seed accessions; 9 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE145379 | False | 34004147 | matches_origin |
| GSE163802 | False | 34004147 | matches_origin |
| GSE163803 | False | 34004147 | matches_origin |
| GSE163804 | False | 34004147 | matches_origin |
| GSE163805 | False | 34004147 | matches_origin |
| GSE40632 | True | 25201415, 36920904 | different_publication |
| GSE58254 | True | 25201415, 36920904 | different_publication |
| GSE58255 | False | 25201415, 36920904 | different_publication |
| GSE68401 | False | 26308897 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 7 |
| europepmc_datalinks | complete | 7 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 7 |
