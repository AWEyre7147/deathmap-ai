# GEO accessions — PMID 34364401

Metabolic impairment of non-small cell lung cancers by mitochondrial HSPD1 targeting.

3 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE30219 | False | 23698379 | different_publication |
| GSE36133 | False | 22460905 | different_publication |
| GSE36138 | True | 22460905 | different_publication |
| GSE36139 | True | 22460905 | different_publication |
| GSE47206 | False | 24908424 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 3 |
