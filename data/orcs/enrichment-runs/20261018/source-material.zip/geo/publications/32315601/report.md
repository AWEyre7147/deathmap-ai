# GEO accessions — PMID 32315601

MYC Controls the Epstein-Barr Virus Lytic Switch.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE140651 | False | 32315601 | matches_origin |
| GSE140652 | False | 32315601 | matches_origin |
| GSE140653 | False | 32315601 | matches_origin |
| GSE36354 | False | 23021215 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 3 |
