# GEO accessions — PMID 31564637

An Evolutionarily Conserved Function of Polycomb Silences the MHC Class I Antigen Presentation Pathway and Enables Immune Evasion in Cancer.

8 seed accessions; 19 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE100538 | True | 29379199 | different_publication |
| GSE129380 | False | 31564637 | matches_origin |
| GSE129381 | False | 31564637 | matches_origin |
| GSE129382 | False | 31564637 | matches_origin |
| GSE31755 | False | (none) | not_reported |
| GSE43346 | False | 23714854 | different_publication |
| GSE60052 | False | 27093186 | different_publication |
| GSE80149 | True | 29379199 | different_publication |
| GSE80150 | True | 29379199 | different_publication |
| GSE80151 | False | 29379199 | different_publication |
| GSE80152 | True | 29379199 | different_publication |
| GSE80153 | True | 29379199 | different_publication |
| GSE80154 | True | 29379199 | different_publication |
| GSE89434 | True | 28360266 | different_publication |
| GSE89435 | False | 28360266 | different_publication |
| GSE89436 | True | 28360266 | different_publication |
| GSE89437 | True | 28360266 | different_publication |
| GSE99312 | True | 23714854 | different_publication |
| GSE99316 | True | 23714854 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 6 |
| europepmc_datalinks | complete | 6 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 17 |
