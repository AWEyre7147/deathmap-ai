# GEO accessions — PMID 29662178

Defining essential genes for human pluripotent stem cells by CRISPR-Cas9 screening in haploid cells.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE103846 | False | 29662178 | matches_origin |
| GSE107965 | False | 29662178 | matches_origin |
| GSE111309 | False | 29662178 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 0 |
