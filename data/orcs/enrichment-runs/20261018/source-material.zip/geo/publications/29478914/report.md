# GEO accessions — PMID 29478914

Genome-wide CRISPR-Cas9 Screen Identifies Leukemia-Specific Dependence on a Pre-mRNA Metabolic Pathway Regulated by DCPS.

1 seed accessions; 1 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE107288 | False | 29478914 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
