# GEO accessions — PMID 31160565

Neuronal differentiation and cell-cycle programs mediate response to BET-bromodomain inhibition in MYC-driven medulloblastoma.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE122404 | False | 31160565 | matches_origin |
| GSE129521 | False | 31160565 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
