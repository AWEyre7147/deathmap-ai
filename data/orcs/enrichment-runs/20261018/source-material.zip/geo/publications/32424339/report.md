# GEO accessions — PMID 32424339

DNA methylation enzymes and PRC1 restrict B-cell Epstein-Barr virus oncoprotein expression.

4 seed accessions; 6 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE136596 | False | 32424339 | matches_origin |
| GSE136597 | False | 32424339 | matches_origin |
| GSE136609 | False | 32424339 | matches_origin |
| GSE24863 | True | 24013550 | different_publication |
| GSE24918 | True | 24013550 | different_publication |
| GSE24919 | False | 24013550 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 3 |
