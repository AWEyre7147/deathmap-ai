# GEO accessions — PMID 30224801

A CRISPR screen identifies IFI6 as an ER-resident interferon effector that blocks flavivirus replication.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE105771 | False | 30224801 | matches_origin |
| GSE121710 | False | 30224801 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
