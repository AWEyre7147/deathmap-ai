# GEO accessions — PMID 36801923

CRISPR screens identify novel regulators of cFLIP dependency and ligand-independent, TRAIL-R1-mediated cell death.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE210445 | False | (none) | not_reported |
| GSE210446 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
