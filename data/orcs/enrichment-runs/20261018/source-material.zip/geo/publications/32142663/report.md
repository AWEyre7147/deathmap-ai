# GEO accessions — PMID 32142663

Genome-Scale CRISPR Screening in Human Intestinal Organoids Identifies Drivers of TGF-β Resistance.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE145182 | False | 32142663 | matches_origin |
| GSE145183 | False | 32142663 | matches_origin |
| GSE145184 | False | 32142663 | matches_origin |
| GSE145185 | False | 32142663 | matches_origin |
| GSE145308 | False | 32142663 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
