# GEO accessions — PMID 33501440

BRD2 inhibition blocks SARS-CoV-2 infection in vitro by reducing transcription of the host cell receptor ACE2

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE165012 | False | 33501440 | matches_origin |
| GSE165025 | False | 33501440 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
