# GEO accessions — PMID 31287994

Mubritinib Targets the Electron Transport Chain Complex I and Reveals the Landscape of OXPHOS Dependency in Acute Myeloid Leukemia.

1 seed accessions; 1 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE130906 | False | 31287994 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
