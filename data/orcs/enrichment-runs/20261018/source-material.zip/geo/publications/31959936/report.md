# GEO accessions — PMID 31959936

Lipid-droplet-accumulating microglia represent a dysfunctional and proinflammatory state in the aging brain.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE139542 | False | 31959936 | matches_origin |
| GSE139946 | False | 31959936 | matches_origin |
| GSE140009 | False | 31959936 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 0 |
