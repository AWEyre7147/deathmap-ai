# GEO accessions — PMID 32939090

Plasticity of ether lipids promotes ferroptosis susceptibility and evasion.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE126696 | False | 30962421 | different_publication |
| GSE148297 | False | (none) | not_reported |
| GSE151062 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
