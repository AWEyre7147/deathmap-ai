# GEO accessions — PMID 31818950

A -element within the locus mediates repression of expression via long-range chromatin interactions.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE125666 | False | 31818950 | matches_origin |
| GSE125841 | False | 31818950 | matches_origin |
| GSE125842 | False | 31818950 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 3 |
