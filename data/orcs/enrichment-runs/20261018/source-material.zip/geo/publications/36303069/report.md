# GEO accessions — PMID 36303069

CRISPRi screens in human iPSC-derived astrocytes elucidate regulators of distinct inflammatory reactive states.

8 seed accessions; 24 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE120411 | False | 30409508 | different_publication |
| GSE129606 | True | 32051591, 40537468 | different_publication |
| GSE129607 | True | 32051591, 40537468 | different_publication |
| GSE129608 | True | 32051591, 40537468 | different_publication |
| GSE129609 | True | 32051591, 40537468 | different_publication |
| GSE129762 | True | 32051591, 40537468 | different_publication |
| GSE129763 | True | 32051591, 40537468 | different_publication |
| GSE129773 | True | 32051591, 40537468 | different_publication |
| GSE129774 | True | 32051591, 40537468 | different_publication |
| GSE130105 | True | 32051591, 40537468 | different_publication |
| GSE130118 | True | 32051591, 40537468 | different_publication |
| GSE130119 | False | 32051591, 40537468 | different_publication |
| GSE135571 | True | 32051591, 40537468 | different_publication |
| GSE137314 | True | 32051591, 40537468 | different_publication |
| GSE143598 | False | 32719333 | different_publication |
| GSE148610 | True | 34413515 | different_publication |
| GSE148611 | False | 34413515 | different_publication |
| GSE148612 | True | 34413515 | different_publication |
| GSE165069 | True | 34413515 | different_publication |
| GSE165098 | True | 34413515 | different_publication |
| GSE182307 | False | 36303069 | matches_origin |
| GSE182308 | False | 36303069 | matches_origin |
| GSE182309 | False | 36303069 | matches_origin |
| GSE76097 | False | 27027288 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 7 |
| europepmc_datalinks | complete | 7 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 21 |
