# GEO accessions — PMID 35750052

Genome-wide CRISPR screens of T cell exhaustion identify chromatin remodeling factors that limit T cell persistence.

4 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE122675 | True | 30778252 | different_publication |
| GSE122712 | True | 30778252 | different_publication |
| GSE122713 | True | 30778252 | different_publication |
| GSE123235 | True | 30778252 | different_publication |
| GSE123236 | False | 30778252 | different_publication |
| GSE203591 | False | 35750052 | matches_origin |
| GSE203592 | False | 35750052 | matches_origin |
| GSE203593 | False | 35750052 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 8 |
