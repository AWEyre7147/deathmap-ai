# GEO accessions — PMID 31509742

Natural Killer Cells Suppress T Cell-Associated Tumor Immune Evasion.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE134261 | False | 31509742 | matches_origin |
| GSE134262 | False | 31509742 | matches_origin |
| GSE134263 | False | 31509742 | matches_origin |
| GSE134264 | False | 31509742 | matches_origin |
| GSE134265 | False | 31509742 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
