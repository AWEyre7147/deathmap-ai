# GEO accessions — PMID 33357464

Functional interrogation of a SARS-CoV-2 host protein interactome identifies unique and shared coronavirus host factors.

3 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE148729 | False | 33585804 | different_publication |
| GSE162039 | False | 33357464 | matches_origin |
| GSE64675 | True | 25768906 | different_publication |
| GSE64676 | True | 25768906 | different_publication |
| GSE64677 | False | 25768906 | different_publication |
| GSE64678 | True | 25768906 | different_publication |
| GSE64679 | True | 25768906 | different_publication |
| GSE64680 | True | 25768906 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 6 |
