# GEO accessions — PMID 33660365

A novel p53 regulator, C16ORF72/TAPR1, buffers against telomerase inhibition.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE160843 | False | 33660365 | matches_origin |
| GSE160865 | False | 33660365 | matches_origin |
| GSE160867 | False | 33660365 | matches_origin |
| GSE160869 | False | 33660365 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
