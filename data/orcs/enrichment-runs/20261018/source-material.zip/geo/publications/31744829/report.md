# GEO accessions — PMID 31744829

In vivo epigenetic CRISPR screen identifies Asf1a as an immunotherapeutic target in Kras-mutant lung adenocarcinoma.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE127205 | False | 31744829 | matches_origin |
| GSE127232 | False | 31744829 | matches_origin |
| GSE133604 | False | 31744829 | matches_origin |
| GSE138571 | False | 31744829 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 0 |
