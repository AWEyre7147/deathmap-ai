# GEO accessions — PMID 32259488

Genetic Screen for Cell Fitness in High or Low Oxygen Highlights Mitochondrial and Lipid Metabolism.

1 seed accessions; 1 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE144527 | False | 32259488 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
