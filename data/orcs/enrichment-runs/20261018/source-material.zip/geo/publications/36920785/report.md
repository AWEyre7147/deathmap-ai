# GEO accessions — PMID 36920785

The mitochondrial pyruvate carrier complex potentiates the efficacy of proteasome inhibitors in multiple myeloma.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE2113 | False | 15735737 | different_publication |
| GSE6477 | False | 17409404, 19996089, 20220778, 21468039 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
