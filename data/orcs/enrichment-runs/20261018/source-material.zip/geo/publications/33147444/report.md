# GEO accessions — PMID 33147444

Genome-wide CRISPR Screens Reveal Host Factors Critical for SARS-CoV-2 Infection.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE154761 | False | 33147444 | matches_origin |
| GSE154782 | False | 33147444 | matches_origin |
| GSE154783 | False | 33147444 | matches_origin |
| GSE154784 | False | 33147444 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 3 |
