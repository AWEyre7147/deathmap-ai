# GEO accessions — PMID 32968282

Functional genomic landscape of cancer-intrinsic evasion of killing by T cells.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE149933 | False | 32968282 | matches_origin |
| GSE149934 | False | 32968282 | matches_origin |
| GSE149935 | False | 32968282 | matches_origin |
| GSE149936 | False | 32968282 | matches_origin |
| GSE153397 | False | 32968282 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
