# GEO accessions — PMID 33813748

Loss-of-Function Genetic Screening Identifies Aldolase A as an Essential Driver for Liver Cancer Cell Growth Under Hypoxia.

5 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE143233 | True | 32368828 | different_publication |
| GSE143234 | True | 32368828 | different_publication |
| GSE143235 | False | 32368828 | different_publication |
| GSE144527 | False | 32259488 | different_publication |
| GSE16347 | False | 19255431, 19828020 | different_publication |
| GSE168544 | False | (none) | not_reported |
| GSE5364 | False | 18636107 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 5 |
| europepmc_datalinks | complete | 5 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 3 |
