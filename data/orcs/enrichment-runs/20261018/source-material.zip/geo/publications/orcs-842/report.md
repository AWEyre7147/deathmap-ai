# GEO accessions — PMID unavailable

Genome-wide CRISPR screens identify noncanonical translation factor eIF2A as an enhancer of SARS-CoV-2 programmed –1 ribosomal frameshifting

1 seed accessions; 1 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE223690 | False | 37581984 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | skipped_missing_pmid | 0 |
| pubmed_accession_list | skipped_missing_pmid | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | skipped_missing_pmid | 0 |
| europepmc_datalinks | skipped_missing_pmid | 0 |
| pubmed_bioproject_geo | skipped_missing_pmid | 0 |
| series_hierarchy | complete | 0 |
