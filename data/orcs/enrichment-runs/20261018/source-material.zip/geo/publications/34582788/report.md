# GEO accessions — PMID 34582788

In vivo CRISPR screens identify the E3 ligase Cop1 as a modulator of macrophage infiltration and cancer immunotherapy target.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE171467 | False | (none) | not_reported |
| GSE173296 | False | (none) | not_reported |
| GSE174784 | False | (none) | not_reported |
| GSE175332 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
