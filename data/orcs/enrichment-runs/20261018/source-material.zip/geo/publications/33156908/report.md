# GEO accessions — PMID 33156908

FBXO11-mediated proteolysis of BAHD1 relieves PRC2-dependent transcriptional repression in erythropoiesis.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE115357 | False | 33156908 | matches_origin |
| GSE290717 | False | (none) | not_reported |
| GSE291329 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 2 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 3 |
