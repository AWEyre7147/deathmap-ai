# GEO accessions — PMID 31209294

Myc and Dnmt1 impede the pluripotent to totipotent state transition in embryonic stem cells.

7 seed accessions; 18 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE121451 | False | 31209294 | matches_origin |
| GSE121457 | False | 31209294 | matches_origin |
| GSE121458 | False | 31209294 | matches_origin |
| GSE121459 | False | 31209294 | matches_origin |
| GSE128307 | False | 31209294 | matches_origin |
| GSE72379 | True | 28459457 | different_publication |
| GSE85529 | True | 28130225 | different_publication |
| GSE85624 | True | 28459457 | different_publication |
| GSE85627 | True | 28459457 | different_publication |
| GSE85632 | True | 28459457 | different_publication |
| GSE85685 | True | 28130225 | different_publication |
| GSE85687 | True | 28130225 | different_publication |
| GSE85688 | True | 28130225 | different_publication |
| GSE85766 | False | 28130225 | different_publication |
| GSE95515 | True | 28459457 | different_publication |
| GSE95516 | True | 28459457 | different_publication |
| GSE95517 | False | 28459457 | different_publication |
| GSE95519 | True | 28459457 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 18 |
