# GEO accessions — PMID 36820830

Genome-wide CRISPR/Cas9 screens reveal shared and cell-specific mechanisms of resistance to SHP2 inhibition.

1 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE212231 | True | (none) | not_reported |
| GSE218488 | True | (none) | not_reported |
| GSE218489 | True | (none) | not_reported |
| GSE218491 | False | 36820830 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 4 |
