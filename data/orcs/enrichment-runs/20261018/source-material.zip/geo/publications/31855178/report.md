# GEO accessions — PMID 31855178

TLE3 loss confers AR inhibitor resistance by facilitating GR-mediated human prostate cancer cell growth.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE130246 | False | 31855178 | matches_origin |
| GSE94682 | False | 28925401, 31855178 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 2 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
