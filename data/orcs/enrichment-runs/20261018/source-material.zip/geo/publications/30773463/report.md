# GEO accessions — PMID 30773463

Systematic Dissection of the Metabolic-Apoptotic Interface in AML Reveals Heme Biosynthesis to Be a Regulator of Drug Sensitivity.

1 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE13159 | False | 18573112, 20406941 | different_publication |
| GSE13164 | True | 18573112, 20406941 | different_publication |
| GSE13204 | True | 18573112, 20406941, 20065290 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 3 |
