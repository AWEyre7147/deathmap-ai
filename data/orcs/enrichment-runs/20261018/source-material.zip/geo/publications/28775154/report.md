# GEO accessions — PMID 28775154

A genome-wide CRISPR screen reconciles the role of N-linked glycosylation in galectin-3 transport to the cell surface.

0 seed accessions; 0 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
