# GEO accessions — PMID 35021089

SCP4-STK35/PDIK1L complex is a dual phospho-catalytic signaling dependency in acute myeloid leukemia.

3 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE104307 | True | 29316427 | different_publication |
| GSE104308 | False | 29316427 | different_publication |
| GSE104309 | True | 29316427 | different_publication |
| GSE109491 | False | 29526696 | different_publication |
| GSE109492 | True | 29526696 | different_publication |
| GSE109493 | True | 29526696 | different_publication |
| GSE174169 | False | 35021089 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 6 |
