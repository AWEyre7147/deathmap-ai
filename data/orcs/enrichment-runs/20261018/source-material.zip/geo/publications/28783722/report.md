# GEO accessions — PMID 28783722

Identification of essential genes for cancer immunotherapy.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE2638 | False | 16617158 | different_publication |
| GSE3920 | False | 17202376, 19553003 | different_publication |
| GSE5542 | False | 16800785 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
