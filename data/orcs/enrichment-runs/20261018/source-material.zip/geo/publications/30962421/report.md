# GEO accessions — PMID 30962421

A GPX4-dependent cancer cell state underlies the clear-cell morphology and confers sensitivity to ferroptosis.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE115389 | False | 30962421 | matches_origin |
| GSE126696 | False | 30962421 | matches_origin |
| GSE34871 | False | 22406644 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
