# GEO accessions — PMID 36772830

Systematic identification of factors involved in the silencing of germline genes in mouse embryonic stem cells.

11 seed accessions; 30 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE101769 | True | 29513657 | different_publication |
| GSE130735 | False | 32561758 | different_publication |
| GSE136226 | True | (none) | not_reported |
| GSE136227 | True | (none) | not_reported |
| GSE136228 | True | (none) | not_reported |
| GSE149341 | False | (none) | not_reported |
| GSE175615 | False | 35317801 | different_publication |
| GSE192556 | False | 36772830 | matches_origin |
| GSE49621 | True | 24835570 | different_publication |
| GSE49622 | True | 24835570 | different_publication |
| GSE49623 | True | 24835570 | different_publication |
| GSE49624 | False | 24835570 | different_publication |
| GSE56697 | False | 24813617 | different_publication |
| GSE57095 | True | 24835570 | different_publication |
| GSE57096 | True | 24835570 | different_publication |
| GSE57097 | True | 24835570 | different_publication |
| GSE67867 | False | 26675734 | different_publication |
| GSE76957 | True | 29513657 | different_publication |
| GSE76958 | False | 29513657 | different_publication |
| GSE76962 | True | 29513657 | different_publication |
| GSE76971 | True | 29513657 | different_publication |
| GSE76973 | True | 29513657 | different_publication |
| GSE77420 | False | 27237052 | different_publication |
| GSE84480 | False | 28304275 | different_publication |
| GSE87484 | True | 28304275 | different_publication |
| GSE87485 | True | 28304275 | different_publication |
| GSE97778 | True | 29686265 | different_publication |
| GSE98149 | True | 29686265 | different_publication |
| GSE98150 | False | 29686265 | different_publication |
| GSE98151 | True | 29686265 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 11 |
| europepmc_datalinks | complete | 11 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 24 |
