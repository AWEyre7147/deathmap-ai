# GEO accessions — PMID 30860482

Renal medullary carcinomas depend upon loss and are sensitive to proteasome inhibition.

6 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE111787 | False | 30860482 | matches_origin |
| GSE36133 | False | 22460905 | different_publication |
| GSE36138 | True | 22460905 | different_publication |
| GSE36139 | True | 22460905 | different_publication |
| GSE64019 | False | 26818002 | different_publication |
| GSE70421 | False | 26433572 | different_publication |
| GSE70678 | False | 26923874, 31708418 | different_publication |
| GSE94321 | False | 28427232 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 6 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 5 |
| europepmc_datalinks | complete | 5 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 3 |
