# GEO accessions — PMID 36228039

LRRC15 inhibits SARS-CoV-2 cellular entry in trans.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE147507 | False | 32416070, 33782412 | different_publication |
| GSE150316 | False | 33298930 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
