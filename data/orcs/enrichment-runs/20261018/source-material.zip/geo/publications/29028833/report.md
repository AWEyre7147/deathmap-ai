# GEO accessions — PMID 29028833

Merkel cell polyomavirus recruits MYCL to the EP400 complex to promote oncogenesis.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE100183 | False | 29028833 | matches_origin |
| GSE69876 | False | 29028833 | matches_origin |
| GSE69877 | False | 29028833 | matches_origin |
| GSE69878 | False | 29028833 | matches_origin |
| GSE79968 | False | 27880818 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
