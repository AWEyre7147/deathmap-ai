# GEO accessions — PMID 32499641

CRISPR screen in regulatory T cells reveals modulators of Foxp3.

3 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE140102 | False | 32499641 | matches_origin |
| GSE40684 | False | 23021222 | different_publication |
| GSE40685 | True | 23021222 | different_publication |
| GSE40686 | False | 23021222 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 3 |
