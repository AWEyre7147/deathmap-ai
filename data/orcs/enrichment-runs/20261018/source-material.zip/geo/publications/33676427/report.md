# GEO accessions — PMID 33676427

Inhibition of ERAD synergizes with FTS to eradicate pancreatic cancer cells.

1 seed accessions; 1 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE162065 | False | 33676427, 36396656 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
