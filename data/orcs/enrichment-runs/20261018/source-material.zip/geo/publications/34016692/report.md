# GEO accessions — PMID 34016692

Protein neddylation as a therapeutic target in pulmonary and extrapulmonary small cell carcinomas.

1 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE171250 | True | (none) | not_reported |
| GSE171255 | True | (none) | not_reported |
| GSE171260 | True | (none) | not_reported |
| GSE171262 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 4 |
