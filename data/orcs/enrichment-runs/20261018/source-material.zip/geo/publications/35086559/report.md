# GEO accessions — PMID 35086559

Genome-scale CRISPR screens identify host factors that promote human coronavirus infection.

7 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE158298 | False | 33147445, 33880488 | different_publication |
| GSE162038 | False | 33382968 | different_publication |
| GSE162039 | False | 33357464 | different_publication |
| GSE177537 | False | 35086559 | matches_origin |
| GSE177541 | False | 35086559 | matches_origin |
| GSE177543 | False | 35086559 | matches_origin |
| GSE177545 | False | 35086559 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
