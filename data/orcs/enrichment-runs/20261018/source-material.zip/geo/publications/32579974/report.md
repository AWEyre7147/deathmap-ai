# GEO accessions — PMID 32579974

Multimodal Analysis of Composition and Spatial Architecture in Human Squamous Cell Carcinoma.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE144236 | False | 32579974, 40120584, 41872488 | matches_origin |
| GSE144237 | False | 32579974, 38037084 | matches_origin |
| GSE144238 | False | 32579974 | matches_origin |
| GSE144239 | False | 32579974, 38037084, 41872488 | matches_origin |
| GSE144240 | False | 32579974, 38037084, 41872488 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
