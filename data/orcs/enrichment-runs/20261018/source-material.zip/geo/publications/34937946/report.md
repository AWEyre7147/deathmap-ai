# GEO accessions — PMID 34937946

Valine tRNA levels and availability regulate complex I assembly in leukaemia.

8 seed accessions; 14 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE115893 | True | 32203470 | different_publication |
| GSE115894 | False | 32203470 | different_publication |
| GSE115895 | True | 32203470 | different_publication |
| GSE115896 | True | 32203470 | different_publication |
| GSE134761 | True | 32203470 | different_publication |
| GSE134762 | True | 32203470 | different_publication |
| GSE139449 | True | 32203470 | different_publication |
| GSE165661 | False | 34937946 | matches_origin |
| GSE165734 | False | 34937946 | matches_origin |
| GSE165736 | False | 34937946 | matches_origin |
| GSE167534 | False | 34937946 | matches_origin |
| GSE167535 | False | 34937946 | matches_origin |
| GSE33469 | False | 22162831 | different_publication |
| GSE33470 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 8 |
| europepmc_datalinks | complete | 8 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 12 |
