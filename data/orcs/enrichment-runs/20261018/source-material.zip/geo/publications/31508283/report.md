# GEO accessions — PMID 31508283

Genome-Wide CRISPR-Cas9 Screening Identifies NF-κB/E2F6 Responsible for EGFRvIII-Associated Temozolomide Resistance in Glioblastoma.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE112733 | False | 31508283 | matches_origin |
| GSE112734 | False | 31508283 | matches_origin |
| GSE112735 | False | 31508283 | matches_origin |
| GSE112736 | False | 31508283 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
