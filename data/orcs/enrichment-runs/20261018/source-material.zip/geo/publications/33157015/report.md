# GEO accessions — PMID 33157015

Zmat3 Is a Key Splicing Regulator in the p53 Tumor Suppression Program.

5 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE145430 | False | (none) | not_reported |
| GSE14553 | True | 19692669 | different_publication |
| GSE14554 | True | 19692669 | different_publication |
| GSE14555 | False | 19692669 | different_publication |
| GSE27901 | False | 21565614, 25704813 | different_publication |
| GSE46240 | False | 23651856, 25704813 | different_publication |
| GSE55727 | False | 25883152 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 5 |
| europepmc_datalinks | complete | 5 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 3 |
