# GEO accessions — PMID 36055241

Whole-genome CRISPR screening identifies genetic manipulations to reduce immune rejection of stem cell-derived islets.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE200083 | False | 36055241 | matches_origin |
| GSE200084 | False | 36055241 | matches_origin |
| GSE200085 | False | 36055241 | matches_origin |
| GSE200104 | False | 36055241 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
