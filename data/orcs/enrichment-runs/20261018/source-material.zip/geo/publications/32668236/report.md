# GEO accessions — PMID 32668236

Ribosome Recycling by ABCE1 Links Lysosomal Function and Iron Homeostasis to 3' UTR-Directed Regulation and Nonsense-Mediated Decay.

6 seed accessions; 6 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE144162 | False | 32668236 | matches_origin |
| GSE144163 | False | 32668236 | matches_origin |
| GSE144164 | False | 32668236 | matches_origin |
| GSE144165 | False | 32668236 | matches_origin |
| GSE150523 | False | 32668236 | matches_origin |
| GSE150524 | False | 32668236 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 6 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 6 |
| series_hierarchy | complete | 6 |
