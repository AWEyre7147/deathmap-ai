# GEO accessions — PMID 36991492

CRISPR screens identify gene targets at breast cancer risk loci.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE219163 | False | 36991492 | matches_origin |
| GSE219164 | False | 36991492 | matches_origin |
| GSE219166 | False | 36991492 | matches_origin |
| GSE219168 | False | 36991492 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 4 |
