# GEO accessions — PMID 35508460

Identification of DAXX as a restriction factor of SARS-CoV-2 through a CRISPR/Cas9 screen.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE145926 | False | 32398875, 39369126 | different_publication |
| GSE173418 | False | (none) | not_reported |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
