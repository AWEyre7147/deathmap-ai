# GEO accessions — PMID 30797773

Convergent Identification and Interrogation of Tumor-Intrinsic Factors that Modulate Cancer Immunity In Vivo.

3 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE123824 | False | 30797773 | matches_origin |
| GSE15907 | False | 21307297, 21859845, 22466668, 22473038, 22797772, 23396170, 23023392, 25135627, 23644507, 23624555, 25279834 | different_publication |
| GSE63269 | True | 26000488, 32888429 | different_publication |
| GSE63472 | False | 26000488, 32888429 | different_publication |
| GSE63473 | True | 26000488, 32888429 | different_publication |
| GSE66693 | True | 26000488, 32888429 | different_publication |
| GSE66694 | True | 26000488, 32888429 | different_publication |
| GSE70151 | True | 26000488, 32888429 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 6 |
