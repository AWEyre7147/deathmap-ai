# GEO accessions — PMID 30930145

The Mitochondrial Transacylase, Tafazzin, Regulates for AML Stemness by Modulating Intracellular Levels of Phospholipids.

3 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE107045 | False | 30930145 | matches_origin |
| GSE24759 | False | 21241896 | different_publication |
| GSE76004 | True | 27926740 | different_publication |
| GSE76008 | False | 27926740 | different_publication |
| GSE76009 | True | 27926740 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 3 |
