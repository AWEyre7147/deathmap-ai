# GEO accessions — PMID 35113687

CRISPR activation and interference screens decode stimulation responses in primary human T cells.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE174255 | False | 35113687 | matches_origin |
| GSE174284 | False | 35113687 | matches_origin |
| GSE174292 | False | 35113687 | matches_origin |
| GSE190604 | False | 35113687 | matches_origin |
| GSE190846 | False | 35113687 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 3 |
