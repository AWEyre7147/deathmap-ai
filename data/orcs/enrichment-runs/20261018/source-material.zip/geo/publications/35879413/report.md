# GEO accessions — PMID 35879413

Bidirectional genome-wide CRISPR screens reveal host factors regulating SARS-CoV-2, MERS-CoV and seasonal HCoVs.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE175666 | False | 35879413 | matches_origin |
| GSE193834 | False | 35879413 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 2 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
