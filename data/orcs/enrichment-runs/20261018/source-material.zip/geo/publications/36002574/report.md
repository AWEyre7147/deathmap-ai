# GEO accessions — PMID 36002574

RASA2 ablation in T cells boosts antigen sensitivity and long-term function.

5 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE119450 | False | 30449619 | different_publication |
| GSE138459 | False | 32661364 | different_publication |
| GSE204862 | False | 36002574 | matches_origin |
| GSE86881 | False | 27789795 | different_publication |
| GSE89307 | False | 28514453 | different_publication |
| GSE89308 | True | 28514453 | different_publication |
| GSE89309 | True | 28514453 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 3 |
