# GEO accessions — PMID 36396656

mTOR inhibition attenuates chemosensitivity through the induction of chemotherapy resistant persisters.

6 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE15781 | False | 19969511 | different_publication |
| GSE162065 | False | 33676427, 36396656 | matches_origin |
| GSE165252 | False | 33504550 | different_publication |
| GSE189764 | False | 36396656 | matches_origin |
| GSE40442 | False | 23297133 | different_publication |
| GSE40870 | True | 23297133 | different_publication |
| GSE40871 | True | 23297133 | different_publication |
| GSE87455 | False | 28940389, 30228933, 29136509 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 3 |
