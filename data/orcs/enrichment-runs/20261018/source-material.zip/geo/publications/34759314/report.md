# GEO accessions — PMID 34759314

Self-guarding of MORC3 enables virulence factor-triggered immunity.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE182752 | False | 34759314 | matches_origin |
| GSE182753 | False | 34759314 | matches_origin |
| GSE182754 | False | 34759314 | matches_origin |
| GSE182755 | False | 34759314 | matches_origin |
| GSE183011 | False | 34759314 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
