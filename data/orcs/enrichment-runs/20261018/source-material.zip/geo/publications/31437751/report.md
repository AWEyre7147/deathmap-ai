# GEO accessions — PMID 31437751

Multi-Omic Approaches Identify Metabolic and Autophagy Regulators Important in Ovarian Cancer Dissemination.

5 seed accessions; 9 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE10971 | False | 18593983, 21263043 | different_publication |
| GSE2109 | False | (none) | not_reported |
| GSE51220 | False | 24070420 | different_publication |
| GSE73064 | False | 30710055 | different_publication |
| GSE73091 | True | 30710055 | different_publication |
| GSE73168 | True | 30710055 | different_publication |
| GSE9890 | True | 18698038 | different_publication |
| GSE9891 | True | 18698038 | different_publication |
| GSE9899 | False | 18698038 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 5 |
| europepmc_datalinks | complete | 5 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 6 |
