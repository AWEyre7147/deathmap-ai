# GEO accessions — PMID 35723366

CRISPR/Cas9 Screening for Identification of Genes Required for the Growth of Ovarian Clear Cell Carcinoma Cells.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE189405 | False | 35377528 | different_publication |
| GSE189553 | False | 35377528 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
