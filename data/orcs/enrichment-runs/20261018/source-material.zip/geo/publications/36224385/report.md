# GEO accessions — PMID 36224385

Activation of γ-globin expression by hypoxia-inducible factor 1α.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE184459 | False | 36224385 | matches_origin |
| GSE184461 | False | 36224385 | matches_origin |
| GSE204897 | False | 36224385 | matches_origin |
| GSE204899 | False | 36224385 | matches_origin |
| GSE204900 | False | 36224385 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 5 |
