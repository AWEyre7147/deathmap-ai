# GEO accessions — PMID 29301958

A major chromatin regulator determines resistance of tumor cells to T cell-mediated killing.

2 seed accessions; 2 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE107670 | False | 29301958 | matches_origin |
| GSE131674 | False | 29301958 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 2 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 2 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 2 |
| series_hierarchy | complete | 0 |
