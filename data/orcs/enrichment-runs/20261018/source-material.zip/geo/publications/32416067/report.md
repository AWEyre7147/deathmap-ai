# GEO accessions — PMID 32416067

Synthetic Lethal and Resistance Interactions with BET Bromodomain Inhibitors in Triple-Negative Breast Cancer.

8 seed accessions; 8 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE131026 | False | 32416067 | matches_origin |
| GSE131030 | False | 32416067 | matches_origin |
| GSE131091 | False | 32416067 | matches_origin |
| GSE131097 | False | 32416067 | matches_origin |
| GSE131099 | False | 32416067 | matches_origin |
| GSE131102 | False | 32416067 | matches_origin |
| GSE131135 | False | 32416067 | matches_origin |
| GSE235793 | False | 32416067 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 8 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 1 |
| europepmc_datalinks | complete | 1 |
| pubmed_bioproject_geo | complete | 8 |
| series_hierarchy | complete | 8 |
