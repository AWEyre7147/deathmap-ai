# GEO accessions — PMID 37024475

PRMT3-mediated arginine methylation of IGF2BP1 promotes oxaliplatin resistance in liver cancer.

5 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE206500 | False | 37024475 | matches_origin |
| GSE206501 | False | 37024475 | matches_origin |
| GSE206502 | False | 37024475 | matches_origin |
| GSE206503 | False | 37024475 | matches_origin |
| GSE206504 | False | 37024475 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 5 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 5 |
| series_hierarchy | complete | 0 |
