# GEO accessions — PMID 28611215

Genome-wide CRISPR screen identifies HNRNPL as a prostate cancer dependency regulating RNA splicing.

4 seed accessions; 5 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE72840 | False | 28611215 | matches_origin |
| GSE72841 | True | (none) | not_reported |
| GSE72842 | False | 28611215 | matches_origin |
| GSE72843 | False | 28611215 | matches_origin |
| GSE72844 | False | 28611215 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 5 |
