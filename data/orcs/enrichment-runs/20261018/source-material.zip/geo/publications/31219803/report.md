# GEO accessions — PMID 31219803

A large-scale CRISPR screen and identification of essential genes in cellular senescence bypass.

4 seed accessions; 4 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE15222 | False | 19361613 | different_publication |
| GSE3790 | False | 16467349, 16623940 | different_publication |
| GSE41714 | False | 23590226 | different_publication |
| GSE95587 | False | 29346778 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 4 |
| europepmc_datalinks | complete | 4 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
