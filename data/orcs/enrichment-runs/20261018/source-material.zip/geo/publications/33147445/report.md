# GEO accessions — PMID 33147445

Identification of Required Host Factors for SARS-CoV-2 Infection in Human Cells.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE158298 | False | 33147445, 33880488 | matches_origin |
| GSE159519 | False | 33147445 | matches_origin |
| GSE159522 | False | 33147445 | matches_origin |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 3 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 3 |
| series_hierarchy | complete | 0 |
