# GEO accessions — PMID 38885264

MicroRNA-focused CRISPR/Cas9 screen identifies miR-142 as a key regulator of Epstein-Barr virus reactivation.

0 seed accessions; 0 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 0 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 0 |
| europepmc_annotations | complete | 0 |
| europepmc_datalinks | complete | 0 |
| pubmed_bioproject_geo | complete | 0 |
| series_hierarchy | complete | 0 |
