# GEO accessions — PMID 33846634

Minor intron retention drives clonal hematopoietic disorders and diverse cancer predisposition.

3 seed accessions; 3 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE149455 | False | 33846634 | matches_origin |
| GSE162136 | False | (none) | not_reported |
| GSE63816 | False | 25586593 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 1 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 2 |
| europepmc_annotations | complete | 2 |
| europepmc_datalinks | complete | 2 |
| pubmed_bioproject_geo | complete | 1 |
| series_hierarchy | complete | 0 |
