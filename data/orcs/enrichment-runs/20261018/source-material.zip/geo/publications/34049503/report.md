# GEO accessions — PMID 34049503

Pooled CRISPR screening in pancreatic cancer cells implicates co-repressor complexes as a cause of multiple drug resistance via regulation of epithelial-to-mesenchymal transition.

5 seed accessions; 7 after explicit hierarchy expansion.

| GSE | Hierarchy only | Native PMID(s) | Citation comparison |
|---|---|---|---|
| GSE131596 | False | 34049503 | matches_origin |
| GSE157096 | False | 34049503 | matches_origin |
| GSE158540 | False | 34049503 | matches_origin |
| GSE158541 | False | 34049503 | matches_origin |
| GSE79668 | True | 27282075 | different_publication |
| GSE79669 | True | 27282075 | different_publication |
| GSE79670 | False | 27282075 | different_publication |

Publication association and accession mentions do not establish dataset ownership or screen role.

| Route | Status | Distinct GSEs |
|---|---|---|
| pubmed_geo_links | complete | 4 |
| pubmed_accession_list | complete | 0 |
| publication_title_phrase | complete | 1 |
| europepmc_annotations | complete | 3 |
| europepmc_datalinks | complete | 3 |
| pubmed_bioproject_geo | complete | 4 |
| series_hierarchy | complete | 6 |
